from machine import UART, I2C, Pin
import time

# =========================
# IDs (ASCII bytes)
# =========================
MY_ID = b'6'
ADRIAN_ID = b'1'
BROADCAST_ID = b'X'

# =========================
# Framing
# =========================
HEADER = b'AZ'
FOOTER = b'YB'

# =========================
# UART / I2C / LED
# =========================
uart = UART(1, baudrate=9600, tx=Pin(17), rx=Pin(18))
i2c = I2C(0, scl=Pin(9), sda=Pin(8))
ADS_ADDR = 72
led = Pin(2, Pin.OUT)

# =========================
# Sensor config
# =========================
LIGHT_THRESHOLD = 12000

# =========================
# RX buffer
# =========================
rx_buffer = b""

# =========================
# periodic send timer
# =========================
last_light_send = time.ticks_ms()
LIGHT_SEND_INTERVAL = 5000   # 5 sec

def blink(times, on_ms=120, off_ms=120):
    for _ in range(times):
        led.value(1)
        time.sleep_ms(on_ms)
        led.value(0)
        time.sleep_ms(off_ms)

def read_light():
    i2c.writeto_mem(ADS_ADDR, 1, bytearray([195, 131]))
    time.sleep_ms(10)
    data = i2c.readfrom_mem(ADS_ADDR, 0, 2)
    return int.from_bytes(data, "big", True)

def get_status():
    value = read_light()
    print("raw =", value)
    return b'01' if value >= LIGHT_THRESHOLD else b'00'

def build_packet(sender, receiver, body):
    return HEADER + sender + receiver + body + FOOTER

def send_packet(packet):
    uart.write(packet)
    print("Sent packet:", packet)

def send_msg3():
    value = read_light()
    value_str = str(value).encode()
    while len(value_str) < 5:
        value_str = b'0' + value_str

    # Example: AZ61324000YB
    body = b'3' + MY_ID + value_str
    send_packet(build_packet(MY_ID, ADRIAN_ID, body))

def send_msg13():
    status = get_status()
    led.value(1 if status == b'01' else 0)

    # Example: AZ613601YB
    body = b'36' + status
    send_packet(build_packet(MY_ID, ADRIAN_ID, body))

def send_msg14(error_code=b'01'):
    # Example: AZ614601YB
    body = b'46' + error_code
    send_packet(build_packet(MY_ID, ADRIAN_ID, body))

def send_msg15():
    status = get_status()

    # Example: AZ615601YB
    body = b'56' + status
    send_packet(build_packet(MY_ID, ADRIAN_ID, body))

def process_packet(packet):
    print("Full packet:", packet)

    payload = packet[2:-2]
    print("Payload:", payload)

    if len(payload) < 4:
        print("Too short, ignored")
        return

    sender = payload[0:1]
    receiver = payload[1:2]
    body = payload[2:]

    print("Sender:", sender)
    print("Receiver:", receiver)
    print("Body:", body)

    if sender == MY_ID:
        print("From me, dropped")
        blink(3)
        return

    if receiver == BROADCAST_ID:
        print("Broadcast packet, forwarding")
        uart.write(packet)
        return

    if receiver != MY_ID:
        print("Not for me, forwarding")
        uart.write(packet)
        return

    print("Packet is for me")
    blink(2)

    if len(body) < 2:
        print("No message type")
        return

    msg_type = body[0:2]
    print("Message type:", msg_type)

    if msg_type == b'12':
        print("Received Message 12 for me")

        try:
            send_msg3()
            send_msg13()
            send_msg15()
        except Exception as e:
            print("Error handling Message 12:", e)
            blink(3)
            send_msg14(b'01')
    else:
        print("Unhandled message type for me:", msg_type)

print("Light subsystem ready")

while True:
    if uart.any():
        data = uart.read()
        if data:
            print("Raw received:", data)
            rx_buffer += data
            print("Current buffer:", rx_buffer)

    if len(rx_buffer) > 300:
        print("RX buffer overflow, trimming")
        rx_buffer = rx_buffer[-20:]

    while True:
        start = rx_buffer.find(HEADER)

        if start == -1:
            if len(rx_buffer) > 10:
                print("No header found, trimming buffer")
                rx_buffer = rx_buffer[-1:]
            break

        if start > 0:
            print("Dropping junk before header:", rx_buffer[:start])
            rx_buffer = rx_buffer[start:]

        end = rx_buffer.find(FOOTER, len(HEADER))
        if end == -1:
            break

        packet = rx_buffer[:end + len(FOOTER)]
        rx_buffer = rx_buffer[end + len(FOOTER):]

        process_packet(packet)

    # send light data every 5 sec
    if time.ticks_diff(time.ticks_ms(), last_light_send) >= LIGHT_SEND_INTERVAL:
        try:
            send_msg3()
        except Exception as e:
            print("Error sending periodic Message 3:", e)
            send_msg14(b'01')
        last_light_send = time.ticks_ms()

    time.sleep_ms(10)